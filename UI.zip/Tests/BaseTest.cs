using NUnit.Framework;
using OpenQA.Selenium;
using AutomationFramework.Core.Driver;
using NUnit.Allure.Attributes;
using NUnit.Allure.Core;

namespace AutomationFramework.Tests
{
    [AllureNUnit]
    [AllureDisplayIgnored]
    public class BaseTest
    {
        protected IWebDriver Driver;

        [SetUp]
        public void Setup()
        {
            Driver = WebDriverFactory.CreateDriver();
        }

        [TearDown]
        public void TearDown()
        {
            Driver.Quit();
        }
    }
}