using AutomationFramework.Core.Utilities;
using AutomationFramework.API.Models;
namespace AutomationFramework.API.Clients
{
    public class UserApiClient
    {
        private readonly ApiHelper _api;
        public UserApiClient(string baseUrl) { _api = new ApiHelper(baseUrl); }
        public UserResponse GetUser(int id) { var response = _api.Get($"/users/{id}"); return System.Text.Json.JsonSerializer.Deserialize<UserResponse>(response.Content); }
    }
}