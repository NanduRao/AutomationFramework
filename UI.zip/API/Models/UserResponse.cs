namespace AutomationFramework.API.Models
{
    public class UserResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}