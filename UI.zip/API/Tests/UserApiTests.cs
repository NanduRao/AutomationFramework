using NUnit.Framework;
using AutomationFramework.API.Clients;
using AutomationFramework.Core.Config;
using NUnit.Allure.Attributes;

namespace AutomationFramework.API.Tests
{
    [AllureEpic("API Tests")]
    [AllureFeature("User API")]
    public class UserApiTests
    {
        [Test]
        [AllureSeverity(Allure.Commons.Model.SeverityLevel.critical)]
        [AllureDescription("Verify that GetUser API returns a valid user.")]
        public void GetUser_ShouldReturnValidUser()
        {
            var client = new UserApiClient(ConfigReader.Get("ApiBaseUrl"));
            var user = client.GetUser(1);
            Assert.That(user.Id, Is.EqualTo(1));
        }
    }
}