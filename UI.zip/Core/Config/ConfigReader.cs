using Microsoft.Extensions.Configuration;
namespace AutomationFramework.Core.Config
{
    public static class ConfigReader
    {
        private static IConfiguration config;
        static ConfigReader()
        {
            config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();
        }
        public static string Get(string key)
        {
            return config[key];
        }
    }
}