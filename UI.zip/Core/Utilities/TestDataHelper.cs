namespace AutomationFramework.Core.Utilities
{
    public static class TestDataHelper
    {
        public static string GetSampleUser() { return "TestUser"; }
    }
}