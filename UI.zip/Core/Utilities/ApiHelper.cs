using RestSharp;
namespace AutomationFramework.Core.Utilities
{
    public class ApiHelper
    {
        private readonly RestClient _client;
        public ApiHelper(string baseUrl) { _client = new RestClient(baseUrl); }
        public RestResponse Get(string endpoint) { var request = new RestRequest(endpoint, Method.Get); return _client.Execute(request); }
    }
}