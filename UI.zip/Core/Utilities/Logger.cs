using System;
namespace AutomationFramework.Core.Utilities
{
    public static class Logger
    {
        public static void Info(string message) { Console.WriteLine($"INFO: {message}"); }
    }
}