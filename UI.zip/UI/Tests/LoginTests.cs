using NUnit.Framework;
using OpenQA.Selenium;
using AutomationFramework.Core.Driver;
using AutomationFramework.UI.Pages;
namespace AutomationFramework.UI.Tests
{
    public class LoginTests
    {
        private IWebDriver driver;
        [SetUp] public void Setup() { driver = WebDriverFactory.CreateDriver(); }
        [TearDown] public void TearDown() { driver.Quit(); }
        [Test]
        public void TestLogin() { var loginPage = new LoginPage(driver); loginPage.Login("user", "pass"); Assert.Pass(); }
    }
}